package com.hyewon.adskipper

object Config {

    // 업데이트마다 이 값을 바꿈 -> 앱 켤 때 "업데이트 됐어요!" 화면이 뜸
    const val UPDATE_SIGNAL = "U5-D9KX"
}
