package com.hyewon.adskipper

object Config {
    // 광고 제거 기능 비밀번호 (나중에 더 어렵게 바꿀 자리)
    const val PASSWORD = "123"

    // 업데이트마다 이 값을 바꿈 -> 앱 켤 때 "업데이트 됐어요!" 화면이 뜸
    const val UPDATE_SIGNAL = "U1-KQ7X"
}
