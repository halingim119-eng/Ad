package com.hyewon.adskipper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (prefs.getString("seen", "") != Config.UPDATE_SIGNAL) showUpdate(prefs) else showMain()
    }

    private fun root() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(60, 60, 60, 60)
        setBackgroundColor(Color.WHITE)
    }

    private fun showUpdate(prefs: android.content.SharedPreferences) {
        val l = root()
        l.addView(TextView(this).apply {
            text = "업데이트 됐어요!"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.BLACK)
        })
        l.addView(TextView(this).apply {
            text = "신호값: ${Config.UPDATE_SIGNAL}"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(Color.GRAY); setPadding(0, 24, 0, 48)
        })
        l.addView(Button(this).apply {
            text = "확인"
            setOnClickListener { prefs.edit().putString("seen", Config.UPDATE_SIGNAL).apply(); showMain() }
        })
        setContentView(l)
    }

    private fun showMain() {
        val l = root()
        l.addView(TextView(this).apply {
            text = "광고 스킵"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.BLACK)
        })
        l.addView(TextView(this).apply {
            text = "\n접근성에서 '광고 스킵'을 켜면 알림창에 조작 버튼이 생겨요.\n\n" +
                "광고 감지 20초: 20초 동안 광고가 뜨면 자동으로 스킵\n" +
                "자동 켜기: 계속 감지\n" +
                "광고 제거: 비밀번호 입력 후 더 강하게 처리\n"
            textSize = 16f; setTextColor(Color.DKGRAY)
        })
        l.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(l)
    }
}
