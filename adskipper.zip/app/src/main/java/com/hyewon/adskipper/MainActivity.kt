package com.hyewon.adskipper

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (prefs.getString("seen", "") != Config.UPDATE_SIGNAL) showUpdate(prefs) else showMain()
    }

    private fun root() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(60, 60, 60, 60)
        setBackgroundColor(Color.WHITE)
    }

    private fun showUpdate(prefs: android.content.SharedPreferences) {
        val l = root()
        l.addView(TextView(this).apply {
            text = "업데이트 됐어요!"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.BLACK)
        })
        l.addView(TextView(this).apply {
            text = "신호값: ${Config.UPDATE_SIGNAL}"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(Color.GRAY); setPadding(0, 24, 0, 48)
        })
        l.addView(Button(this).apply {
            text = "확인"
            setOnClickListener { prefs.edit().putString("seen", Config.UPDATE_SIGNAL).apply(); showMain() }
        })
        setContentView(l)
    }

    private fun showMain() {
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        val l = root()
        l.addView(TextView(this).apply {
            text = "광고 스킵"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.BLACK)
        })
        l.addView(TextView(this).apply {
            text = "\n접근성에서 '광고 스킵'을 켜면 알림창에 조작 버튼이 생겨요.\n\n" +
                "광고 감지 20초: 20초 동안 광고가 뜨면 자동으로 스킵\n" +
                "자동 켜기: 계속 감지\n" +
                "광고 제거: 켜두면 광고를 더 강하게 닫음\n\n" +
                "※ 진단은 자동이에요. 광고 화면이 뜨면 알아서 기록하고, 6초 넘게 못 닫으면 클립보드에 바로 복사해요. " +
                "그냥 채팅에 붙여넣기 하면 돼요."
            textSize = 16f; setTextColor(Color.DKGRAY)
        })
        l.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        l.addView(Button(this).apply {
            text = "진단 기록 복사"
            setOnClickListener {
                val f = File(filesDir, "diag.txt")
                if (!f.exists() || f.length() == 0L) {
                    Toast.makeText(this@MainActivity, "아직 기록이 없어요. 광고가 뜨면 자동으로 쌓여요", Toast.LENGTH_LONG).show()
                } else {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("adskipper diag", f.readText().take(30000)))
                    Toast.makeText(this@MainActivity, "복사했어요. 채팅에 붙여넣기 하세요", Toast.LENGTH_LONG).show()
                }
            }
        })
        l.addView(Button(this).apply {
            fun label() = if (prefs.getBoolean("diag", true)) "자동 진단: 켜짐 (누르면 끔)" else "자동 진단: 꺼짐 (누르면 켬)"
            text = label()
            setOnClickListener {
                prefs.edit().putBoolean("diag", !prefs.getBoolean("diag", true)).apply()
                sendBroadcast(Intent(AdService.A_DIAG).setPackage(packageName))
                text = label()
            }
        })
        l.addView(Button(this).apply {
            text = "지금 화면 진단 (5초 뒤)"
            setOnClickListener {
                sendBroadcast(Intent(AdService.A_DUMP).setPackage(packageName))
                Toast.makeText(this@MainActivity, "5초 안에 진단할 화면으로 이동하세요", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            }
        })
        setContentView(l)
    }
}
