package com.hyewon.adskipper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (prefs.getString("seen", "") != Config.UPDATE_SIGNAL) {
            showUpdate(prefs)
        } else showMain()
    }

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(60, 60, 60, 60)
        setBackgroundColor(Color.WHITE)
    }

    private fun showUpdate(prefs: android.content.SharedPreferences) {
        val l = root()
        l.addView(TextView(this).apply { text = "🎉"; textSize = 64f; gravity = Gravity.CENTER })
        l.addView(TextView(this).apply {
            text = "업데이트 됐어요!"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.BLACK)
        })
        l.addView(TextView(this).apply {
            text = "신호값: ${Config.UPDATE_SIGNAL}"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(Color.GRAY); setPadding(0, 24, 0, 48)
        })
        l.addView(Button(this).apply {
            text = "확인"
            setOnClickListener {
                prefs.edit().putString("seen", Config.UPDATE_SIGNAL).apply()
                showMain()
            }
        })
        setContentView(l)
    }

    private fun showMain() {
        val l = root()
        l.addView(TextView(this).apply {
            text = "광고 스킵 바"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.BLACK)
        })
        l.addView(TextView(this).apply {
            text = "\n1. 아래 버튼 → 설치된 앱/다운로드한 앱 → '광고 스킵 바' 켜기\n" +
                "2. 켜면 화면 왼쪽에 얇은 바가 떠요\n\n" +
                "📡 감지: 20초 동안 광고 스킵/닫기 버튼 자동 클릭\n" +
                "🔁 자동: 1초마다 계속 감지\n" +
                "🛡 제거: 비밀번호 입력 후 더 강하게 닫기\n"
            textSize = 16f; setTextColor(Color.DKGRAY)
        })
        l.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(l)
    }
}
