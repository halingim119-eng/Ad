package com.hyewon.adskipper

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class PasswordActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(50, 40, 50, 40) }
        l.addView(TextView(this).apply { text = "🛡 광고 제거 - 비밀번호"; textSize = 18f })
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        l.addView(et)
        l.addView(Button(this).apply {
            text = "확인"
            setOnClickListener {
                if (et.text.toString() == Config.PASSWORD) {
                    AdService.instance?.setRemove(true)
                    finish()
                } else {
                    Toast.makeText(this@PasswordActivity, "틀렸어요", Toast.LENGTH_SHORT).show()
                    et.setText("")
                }
            }
        })
        setContentView(l)
    }
}
