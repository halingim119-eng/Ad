package com.hyewon.adskipper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView

class AdService : AccessibilityService() {
    companion object { var instance: AdService? = null }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bar: LinearLayout? = null
    private lateinit var bg: GradientDrawable
    private lateinit var bDetect: TextView
    private lateinit var bAuto: TextView
    private lateinit var bRemove: TextView

    private var detectUntil = 0L
    private var autoOn = false
    private var removeOn = false
    private var lastClick = 0L
    private var lastBack = 0L
    private var barPx = 0

    private val skipWords = listOf("건너뛰기", "광고 건너", "skip ad", "skip ads", "skip", "스킵", "광고 닫기", "close ad", "닫고 계속")
    private val closeExact = listOf("닫기", "close", "dismiss", "x", "×", "✕", "✖", "✗")
    private val adIdHints = listOf("adview", "admob", "interstitial", "native_ad", "banner", "_ad_", "/ad_", "ad_container", "gad", "ads_")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildBar()
        h.post(loop)
        h.post(colorLoop)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        h.removeCallbacksAndMessages(null)
        bar?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (active()) scanThrottled()
    }

    // ---------- 바 UI ----------
    private fun buildBar() {
        barPx = dp(44)
        bg = GradientDrawable().apply {
            setColor(Color.parseColor("#111111"))
            cornerRadii = floatArrayOf(0f, 0f, dp(14).toFloat(), dp(14).toFloat(), dp(14).toFloat(), dp(14).toFloat(), 0f, 0f)
        }
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg
        }
        bDetect = tool("📡") { startDetect() }
        bAuto = tool("🔁") { autoOn = !autoOn; refresh() }
        bRemove = tool("🛡") {
            if (removeOn) setRemove(false)
            else startActivity(Intent(this, PasswordActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        listOf(bDetect, bAuto, bRemove).forEach { bar!!.addView(it, LinearLayout.LayoutParams(barPx, dp(52))) }

        val lp = WindowManager.LayoutParams(
            barPx, (resources.displayMetrics.heightPixels * 0.6).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        wm.addView(bar, lp)
        refresh()
    }

    private fun tool(icon: String, onClick: () -> Unit) = TextView(this).apply {
        text = icon; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setOnClickListener { onClick() }
    }

    private fun refresh() {
        bAuto.alpha = if (autoOn) 1f else 0.45f
        bRemove.alpha = if (removeOn) 1f else 0.45f
        val left = ((detectUntil - System.currentTimeMillis()) / 1000).toInt()
        if (left > 0) { bDetect.text = "$left"; bDetect.alpha = 1f } else { bDetect.text = "📡"; bDetect.alpha = 0.45f }
    }

    fun setRemove(on: Boolean) { removeOn = on; refresh() }

    private fun startDetect() { detectUntil = System.currentTimeMillis() + 20_000; refresh(); scan() }

    private fun active() = autoOn || removeOn || System.currentTimeMillis() < detectUntil

    // ---------- 루프 ----------
    private val loop = object : Runnable {
        override fun run() {
            refresh()
            if (active()) scan()
            h.postDelayed(this, 1000)
        }
    }

    private var lastScan = 0L
    private fun scanThrottled() {
        val n = System.currentTimeMillis()
        if (n - lastScan > 400) scan()
    }

    // ---------- 광고 탐지 + 클릭 ----------
    private fun scan() {
        lastScan = System.currentTimeMillis()
        val root = rootInActiveWindow ?: return
        if (root.packageName == packageName) return

        var adContext = false
        var skipNode: AccessibilityNodeInfo? = null
        var closeNode: AccessibilityNodeInfo? = null
        var idCloseNode: AccessibilityNodeInfo? = null

        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            val t = (n.text?.toString() ?: "").trim().lowercase()
            val d = (n.contentDescription?.toString() ?: "").trim().lowercase()
            val id = (n.viewIdResourceName ?: "").lowercase()

            if (t.contains("광고") || d.contains("광고") || t == "ad" || t == "ads" || t == "sponsored" || d == "ad" || d == "sponsored") adContext = true
            if (adIdHints.any { id.contains(it) }) adContext = true

            if (skipNode == null && n.isVisibleToUser &&
                (skipWords.any { t.contains(it) && t.length <= 14 } || skipWords.any { d.contains(it) && d.length <= 14 } ||
                    id.contains("skip"))) skipNode = n
            if (closeNode == null && n.isVisibleToUser && (t in closeExact || d in closeExact)) closeNode = n
            if (idCloseNode == null && n.isVisibleToUser &&
                (id.contains("close") || id.contains("dismiss") || id.contains("btn_x") || id.contains("x_btn"))) idCloseNode = n

            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)

        val now = System.currentTimeMillis()
        if (now - lastClick < 700) return

        // 1순위: 스킵 버튼 (광고 문맥 없어도 클릭)
        skipNode?.let { click(it); return }
        // 2순위: X/닫기 (광고 문맥이 있을 때만)
        if (adContext) {
            closeNode?.let { click(it); return }
            if (removeOn) idCloseNode?.let { click(it); return }
        }
        // 광고 제거 모드: 광고 화면인데 버튼을 못 찾으면 뒤로가기 (3초 간격)
        if (removeOn && adContext && now - lastBack > 3000) {
            lastBack = now
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun click(n: AccessibilityNodeInfo) {
        lastClick = System.currentTimeMillis()
        var p: AccessibilityNodeInfo? = n
        while (p != null) {
            if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            p = p.parent
        }
        val r = Rect(); n.getBoundsInScreen(r)
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(), null, null)
    }

    // ---------- 주변 색 따라 바 색 바꾸기 ----------
    private val colorLoop = object : Runnable {
        override fun run() {
            sampleColor()
            h.postDelayed(this, 1500)
        }
    }

    private fun sampleColor() {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        r.hardwareBuffer.close()
                        if (bmp != null) {
                            val x0 = (barPx + 6).coerceAtMost(bmp.width - 2)
                            val y0 = (bmp.height * 0.2).toInt()
                            val y1 = (bmp.height * 0.8).toInt()
                            var rs = 0L; var gs = 0L; var bs = 0L; var c = 0
                            var y = y0
                            while (y < y1) {
                                val px = bmp.getPixel(x0, y)
                                rs += Color.red(px); gs += Color.green(px); bs += Color.blue(px); c++
                                y += 12
                            }
                            if (c > 0) applyColor((rs / c).toInt(), (gs / c).toInt(), (bs / c).toInt())
                        }
                    } catch (_: Exception) {}
                }
                override fun onFailure(code: Int) {}
            })
        } catch (_: Exception) {}
    }

    private fun applyColor(r: Int, g: Int, b: Int) {
        val lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        val col = if (lum > 0.45) {
            // 밝은 배경 -> 배경색을 어둡게 한 바
            Color.rgb((r * 0.18).toInt(), (g * 0.18).toInt(), (b * 0.18).toInt())
        } else {
            // 어두운 배경 -> 눈에 띄게 밝은 쪽으로
            Color.rgb(minOf(255, r + 70), minOf(255, g + 70), minOf(255, b + 70))
        }
        bg.setColor(col)
        val txt = if (Color.red(col) * 0.299 + Color.green(col) * 0.587 + Color.blue(col) * 0.114 > 140) Color.BLACK else Color.WHITE
        listOf(bDetect, bAuto, bRemove).forEach { it.setTextColor(txt) }
    }
}
