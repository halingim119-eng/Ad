package com.hyewon.adskipper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AdService : AccessibilityService() {
    companion object {
        var instance: AdService? = null
        const val CH = "ctl"
        const val A_DETECT = "com.hyewon.adskipper.DETECT"
        const val A_AUTO = "com.hyewon.adskipper.AUTO"
        const val A_REMOVE_OFF = "com.hyewon.adskipper.REMOVE_OFF"
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var nm: NotificationManager

    private var detectUntil = 0L
    private var autoOn = false
    private var removeOn = false

    private var adWindow = false      // 광고 SDK 화면이 열린 상태
    private var adStart = 0L
    private var lastClick = 0L
    private var lastBack = 0L
    private var lastScan = 0L

    // 광고 SDK 클래스 이름 (광고가 뜰 때 이 화면/뷰가 생성됨)
    private val adClassHints = listOf(
        "com.google.android.gms.ads", "adactivity", "com.google.ads", "unity3d.ads", "unityads",
        "applovin", "facebook.ads", "ironsource", "vungle", "adcolony", "mbridge", "mintegral",
        "bytedance.sdk.openadsdk", "pangle", "kakao.adfit", "adfit", "inmobi", "chartboost",
        "fyber", "tapjoy", "smaato", "moloco", "admob", "interstitial", "rewardedvideo", "rewardedad",
        "nativead", "adview", "bannerview", "com.mopub", "com.amazon.device.ads", "com.naver.gfa"
    )
    private val adIdHints = listOf("adview", "admob", "interstitial", "native_ad", "ad_container", "ad_close", "ads_", "_ad_", "gad")
    private val skipWords = listOf("건너뛰기", "광고 건너", "skip ad", "skip ads", "skip", "스킵", "광고 닫기", "close ad", "닫고 계속")
    private val closeExact = listOf("닫기", "close", "dismiss", "x", "×", "✕", "✖", "✗")

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                A_DETECT -> startDetect()
                A_AUTO -> { autoOn = !autoOn; notifyState() }
                A_REMOVE_OFF -> setRemove(false)
            }
        }
    }

    override fun onServiceConnected() {
        instance = this
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "광고 스킵 조작", NotificationManager.IMPORTANCE_LOW))
        val f = IntentFilter().apply { addAction(A_DETECT); addAction(A_AUTO); addAction(A_REMOVE_OFF) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
        notifyState()
        h.post(loop)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        h.removeCallbacksAndMessages(null)
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        nm.cancel(1)
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    fun setRemove(on: Boolean) { removeOn = on; notifyState() }

    private fun startDetect() { detectUntil = System.currentTimeMillis() + 20_000; notifyState() }

    private fun active() = autoOn || removeOn || System.currentTimeMillis() < detectUntil

    // ---------- 알림 ----------
    private fun pi(action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(this, code, Intent(action).setPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun notifyState() {
        val left = ((detectUntil - System.currentTimeMillis()) / 1000).toInt()
        val parts = ArrayList<String>()
        if (left > 0) parts.add("광고 감지 중 (${left}초 남음)")
        if (autoOn) parts.add("자동 감지 켜짐")
        if (removeOn) parts.add("광고 제거 켜짐")
        val text = if (parts.isEmpty()) "대기 중" else parts.joinToString(" / ")

        val pwd = PendingIntent.getActivity(this, 4,
            Intent(this, PasswordActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("광고 스킵")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(null, "광고 감지 20초", pi(A_DETECT, 1)).build())
            .addAction(Notification.Action.Builder(null, if (autoOn) "자동 끄기" else "자동 켜기", pi(A_AUTO, 2)).build())
            .addAction(Notification.Action.Builder(null, if (removeOn) "제거 끄기" else "광고 제거",
                if (removeOn) pi(A_REMOVE_OFF, 3) else pwd).build())
            .build()
        nm.notify(1, n)
    }

    // ---------- 광고 발동 감지 ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !active()) return
        if (e.packageName == packageName) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val cls = (e.className?.toString() ?: "").lowercase()
            val was = adWindow
            adWindow = adClassHints.any { cls.contains(it) }
            if (adWindow && !was) adStart = System.currentTimeMillis()
        }
        val n = System.currentTimeMillis()
        if (n - lastScan > 400) scan()
    }

    private val loop = object : Runnable {
        override fun run() {
            if (detectUntil != 0L) {
                if (System.currentTimeMillis() < detectUntil) notifyState()
                else { detectUntil = 0L; notifyState() }
            }
            if (active()) scan()
            h.postDelayed(this, 1000)
        }
    }

    private fun scan() {
        lastScan = System.currentTimeMillis()
        val root = rootInActiveWindow ?: return
        if (root.packageName == packageName) return

        var nodeAd = false
        var skipNode: AccessibilityNodeInfo? = null
        var closeNode: AccessibilityNodeInfo? = null
        var idCloseNode: AccessibilityNodeInfo? = null

        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            val t = (n.text?.toString() ?: "").trim().lowercase()
            val d = (n.contentDescription?.toString() ?: "").trim().lowercase()
            val id = (n.viewIdResourceName ?: "").lowercase()
            val cn = (n.className?.toString() ?: "").lowercase()

            if (adClassHints.any { cn.contains(it) } || adIdHints.any { id.contains(it) }) nodeAd = true

            if (skipNode == null && n.isVisibleToUser &&
                (skipWords.any { t.contains(it) && t.length <= 14 } || skipWords.any { d.contains(it) && d.length <= 14 } ||
                    id.contains("skip"))) skipNode = n
            if (closeNode == null && n.isVisibleToUser && (t in closeExact || d in closeExact)) closeNode = n
            if (idCloseNode == null && n.isVisibleToUser &&
                (id.contains("close") || id.contains("dismiss") || id.contains("btn_x") || id.contains("x_btn"))) idCloseNode = n

            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)

        // 광고가 실제로 발동한 경우에만 동작
        if (!adWindow && !nodeAd) return

        val now = System.currentTimeMillis()
        if (now - lastClick < 700) return

        skipNode?.let { click(it); return }
        closeNode?.let { click(it); return }
        if (adWindow || removeOn) idCloseNode?.let { click(it); return }

        // 광고 제거: 버튼을 못 찾으면 뒤로가기
        if (removeOn && adWindow && now - adStart > 1500 && now - lastBack > 2500) {
            lastBack = now
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun click(n: AccessibilityNodeInfo) {
        lastClick = System.currentTimeMillis()
        var p: AccessibilityNodeInfo? = n
        while (p != null) {
            if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            p = p.parent
        }
        val r = Rect(); n.getBoundsInScreen(r)
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(), null, null)
    }
}
