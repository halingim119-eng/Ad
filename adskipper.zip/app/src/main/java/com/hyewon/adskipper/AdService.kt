package com.hyewon.adskipper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Toast

class AdService : AccessibilityService() {
    companion object {
        const val CH = "ctl"
        const val A_DETECT = "com.hyewon.adskipper.DETECT"
        const val A_AUTO = "com.hyewon.adskipper.AUTO"
        const val A_REMOVE = "com.hyewon.adskipper.REMOVE"
        const val A_DUMP = "com.hyewon.adskipper.DUMP"
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var nm: NotificationManager

    private var detectUntil = 0L
    private var autoOn = false
    private var removeOn = false
    private var lastLeft = -1

    // 광고 전용 액티비티(창)인지: 창 전환 이벤트에서만 갱신, 앱이 바뀌면 해제
    private var adWindow = false
    private var winPkg = ""
    private var winClass = ""
    private var adStart = 0L

    private var lastClick = 0L
    private var lastBack = 0L
    private var lastScan = 0L
    private val clickLog = HashMap<String, ArrayList<Long>>()

    // 광고 전용 화면(액티비티) 클래스 힌트
    private val windowAdHints = listOf(
        "com.google.android.gms.ads", "adactivity", "com.google.ads", "unity3d.ads", "unityads",
        "applovin", "facebook.ads", "ironsource", "vungle", "adcolony", "mbridge", "mintegral",
        "bytedance.sdk.openadsdk", "pangle", "kakao.adfit", "adfit", "inmobi", "chartboost",
        "fyber", "tapjoy", "smaato", "moloco", "admob", "interstitial", "rewardedvideo", "rewardedad",
        "com.mopub", "com.amazon.device.ads", "com.naver.gfa",
        "doubleclick", "googlesyndication", "criteo", "pubmatic", "admanager", "adsdk"
    )
    // 화면 안의 광고 뷰(배너 포함) 클래스 힌트
    private val nodeAdHints = windowAdHints + listOf("nativead", "adview", "bannerview")
    private val adIdHints = listOf(
        "adview", "admob", "interstitial", "native_ad", "ad_container", "ad_close", "ad_layout",
        "ad_frame", "ad_root", "ad_popup", "ad_dialog", "ad_view", "ad_skip", "fullscreen_ad", "ads_", "_ad_"
    )
    private val videoHints = listOf("surfaceview", "textureview", "playerview", "videoview", "exoplayer", "mediaplayer", "videoplayer")

    // 어디서든 누르는 확실한 "광고 건너뛰기" 계열
    private val strongSkip = listOf("건너뛰기", "광고 건너", "skip ad", "skip ads", "광고 닫기", "close ad", "닫고 계속", "광고 끄기", "광고 숨기기", "hide ad")
    // 광고 화면일 때만 누르는 약한 계열
    private val weakSkip = listOf("skip", "스킵")
    private val closeExact = listOf("닫기", "close", "dismiss", "x", "×", "✕", "✖", "✗", "닫음", "cancel ad")
    private val closeWords = listOf("닫기", "close", "dismiss")
    private val closeIds = listOf("close", "dismiss", "btn_x", "x_btn", "ad_x", "iv_x", "img_x", "icon_x", "btn_exit")
    private val cornerBadCls = listOf("edittext", "checkbox", "switch", "seekbar", "progress", "radiobutton", "toggle")
    private val ignorePkgs = listOf("com.android.systemui", "com.google.android.inputmethod", "com.samsung.android.honeyboard")

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                A_DETECT -> { detectUntil = System.currentTimeMillis() + 20_000; lastLeft = -1; notifyState(); requestScan() }
                A_AUTO -> { autoOn = !autoOn; notifyState(); requestScan() }
                A_REMOVE -> { removeOn = !removeOn; notifyState(); requestScan() }
                A_DUMP -> {
                    Toast.makeText(this@AdService, "10초 뒤 화면 구조를 복사해요. 광고 화면으로 가세요", Toast.LENGTH_LONG).show()
                    h.postDelayed({ dump() }, 10_000)
                }
            }
        }
    }

    override fun onServiceConnected() {
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "광고 스킵 조작", NotificationManager.IMPORTANCE_LOW))
        val f = IntentFilter().apply { addAction(A_DETECT); addAction(A_AUTO); addAction(A_REMOVE); addAction(A_DUMP) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
        notifyState()
        h.post(loop)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        h.removeCallbacksAndMessages(null)
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        nm.cancel(1)
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    private fun active() = autoOn || removeOn || System.currentTimeMillis() < detectUntil

    // ---------- 알림 ----------
    private fun pi(action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(this, code, Intent(action).setPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun notifyState() {
        val left = ((detectUntil - System.currentTimeMillis() + 999) / 1000).toInt()
        val parts = ArrayList<String>()
        if (left > 0) parts.add("광고 감지 중 (${left}초 남음)")
        if (autoOn) parts.add("자동 감지 켜짐")
        if (removeOn) parts.add("광고 제거 켜짐")
        val text = if (parts.isEmpty()) "대기 중" else parts.joinToString(" / ")
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("광고 스킵")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(null, "광고 감지 20초", pi(A_DETECT, 1)).build())
            .addAction(Notification.Action.Builder(null, if (autoOn) "자동 끄기" else "자동 켜기", pi(A_AUTO, 2)).build())
            .addAction(Notification.Action.Builder(null, if (removeOn) "제거 끄기" else "광고 제거", pi(A_REMOVE, 3)).build())
            .build()
        nm.notify(1, n)
    }

    // ---------- 이벤트: 즉시 반응 ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !active()) return
        val pkg = e.packageName?.toString() ?: ""
        if (pkg == packageName || ignorePkgs.contains(pkg)) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val cls = (e.className?.toString() ?: "").lowercase()
            // 다이얼로그/기본 위젯 클래스는 광고 창 판정에 쓰지 않음 (판정이 흔들려서 엉뚱한 곳 누르는 원인)
            val generic = cls.isEmpty() || cls.startsWith("android.") || cls.startsWith("androidx.")
            if (!generic) {
                val was = adWindow
                winPkg = pkg
                winClass = cls
                adWindow = windowAdHints.any { cls.contains(it) }
                if (adWindow && !was) adStart = System.currentTimeMillis()
            }
        }
        requestScan()
    }

    private val scanRun = Runnable { scan() }
    private fun requestScan() {
        val gap = System.currentTimeMillis() - lastScan
        h.removeCallbacks(scanRun)
        if (gap >= 100) scan() else h.postDelayed(scanRun, 100 - gap)
    }

    private val loop = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (detectUntil != 0L) {
                val left = ((detectUntil - now + 999) / 1000).toInt()
                if (left != lastLeft) { lastLeft = left; if (left <= 0) detectUntil = 0L; notifyState() }
            }
            if (active()) scan()
            h.postDelayed(this, 300)
        }
    }

    // ---------- 노드 수집 ----------
    private class Nd(
        val n: AccessibilityNodeInfo,
        val t: String,
        val d: String,
        val id: String,
        val cn: String,
        val r: Rect,
        val clickable: Boolean,
        val inAd: Boolean
    )

    private fun collect(root: AccessibilityNodeInfo, out: ArrayList<Nd>) {
        fun walk(n: AccessibilityNodeInfo?, depth: Int, inAd: Boolean) {
            if (n == null || depth > 45 || out.size > 2000) return
            val vis = n.isVisibleToUser
            var ad = inAd
            if (vis) {
                val t = (n.text?.toString() ?: "").trim().lowercase()
                val d = (n.contentDescription?.toString() ?: "").trim().lowercase()
                val id = (n.viewIdResourceName ?: "").lowercase()
                val cn = (n.className?.toString() ?: "").lowercase()
                // 보이는 광고 뷰만 광고로 인정 (숨겨진 미리 로드된 광고 뷰 때문에 오판하던 것 방지)
                if (nodeAdHints.any { cn.contains(it) } || adIdHints.any { id.contains(it) }) ad = true
                val r = Rect(); n.getBoundsInScreen(r)
                out.add(Nd(n, t, d, id, cn, r, n.isClickable, ad))
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, ad)
        }
        walk(root, 0, false)
    }

    // 맨 위(포커스된) 앱 창 하나만 대상 -> 뒤에 깔린 앱 화면을 건드리지 않음
    private fun pickRoot(): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestFocused = false
        var bestLayer = -1
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val r = w.root ?: continue
                val p = r.packageName?.toString() ?: ""
                if (p == packageName || ignorePkgs.contains(p)) continue
                val f = w.isFocused
                if (best == null || (f && !bestFocused) || (f == bestFocused && w.layer > bestLayer)) {
                    best = r; bestFocused = f; bestLayer = w.layer
                }
            }
        } catch (_: Exception) {}
        if (best != null) return best
        val r = rootInActiveWindow ?: return null
        val p = r.packageName?.toString() ?: ""
        return if (p == packageName || ignorePkgs.contains(p)) null else r
    }

    private fun isCloseLabel(s: String): Boolean {
        if (s.isEmpty()) return false
        if (closeExact.contains(s)) return true
        return s.length <= 12 && closeWords.any { s.contains(it) }
    }

    // ---------- 스캔 ----------
    private fun scan() {
        if (!active()) return
        val now = System.currentTimeMillis()
        lastScan = now

        val root = pickRoot() ?: return
        val pkg = root.packageName?.toString() ?: ""
        if (winPkg.isNotEmpty() && pkg != winPkg) adWindow = false

        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val den = dm.density

        val nodes = ArrayList<Nd>()
        collect(root, nodes)
        if (nodes.isEmpty()) return

        // 화면 성격 파악: 눌러볼 게 거의 없고 영상이 있으면 전면 광고일 가능성이 높음
        var interactive = 0
        var hasVideo = false
        var hasWeb = false
        val bigArea = sw.toLong() * sh * 0.6
        for (x in nodes) {
            if (x.clickable && x.r.width().toLong() * x.r.height() < bigArea) interactive++
            if (x.cn.contains("webview")) hasWeb = true
            else if (videoHints.any { x.cn.contains(it) }) hasVideo = true
        }
        val sparse = interactive <= 5
        val aggressive = removeOn || now < detectUntil
        val full = adWindow || (sparse && hasVideo) || (aggressive && (sparse || hasVideo || hasWeb))
        fun ok(x: Nd) = x.inAd || full

        val cands = ArrayList<Nd>()

        // 1) 건너뛰기 (확실한 문구는 어느 화면에서든)
        for (x in nodes) {
            val strong = listOf(x.t, x.d).any { s -> s.isNotEmpty() && s.length <= 16 && strongSkip.any { s.contains(it) } }
            if (strong) cands.add(x)
        }
        for (x in nodes) {
            if (!ok(x)) continue
            val weak = listOf(x.t, x.d).any { s -> s.isNotEmpty() && s.length <= 12 && weakSkip.any { s.contains(it) } } ||
                x.id.substringAfter('/').contains("skip")
            if (weak) cands.add(x)
        }
        // 2) 닫기 / X 문구
        for (x in nodes) {
            if (!ok(x)) continue
            if (x.r.width() >= sw * 0.9 && x.r.height() >= sh * 0.5) continue
            if (isCloseLabel(x.t) || isCloseLabel(x.d)) cands.add(x)
        }
        // 3) close 계열 id
        for (x in nodes) {
            if (!ok(x)) continue
            val sid = x.id.substringAfter('/')
            if (sid.isNotEmpty() && closeIds.any { sid.contains(it) } && x.r.width() <= sw * 0.5 && x.r.height() <= sh * 0.25) cands.add(x)
        }
        // 4) 라벨 없는 X 아이콘: 화면 위쪽 모서리의 작은 버튼 (세로 화면 전면 광고용)
        val minS = (10 * den).toInt()
        val maxS = (80 * den).toInt()
        val corners = nodes.filter { x ->
            x.t.isEmpty() && x.d.isEmpty() &&
                x.r.width() in minS..maxS && x.r.height() in minS..maxS &&
                x.r.top >= 0 && x.r.bottom <= sh * 0.30 &&
                (x.r.centerX() >= sw * 0.70 || x.r.centerX() <= sw * 0.25) &&
                (x.clickable || aggressive) && ok(x) &&
                cornerBadCls.none { x.cn.contains(it) }
        }.sortedByDescending { x ->
            (if (x.clickable) 100 else 0) + (if (x.r.centerX() >= sw * 0.70) 40 else 0) - (x.r.top * 30 / sh)
        }
        cands.addAll(corners)

        if (now - lastClick >= 500) {
            var tried = 0
            for (x in cands) {
                if (tried >= 4) break
                tried++
                if (click(x, den)) return
            }
        }

        // 광고 제거: 광고 전용 화면인데 버튼을 못 찾으면 뒤로가기
        if (removeOn && adWindow && now - adStart > 800 && now - lastBack > 1500 && now - lastClick >= 500) {
            lastBack = now
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    // ---------- 클릭 ----------
    private fun click(x: Nd, den: Float): Boolean {
        val n = x.n
        // 이미 사라진/바뀐 노드의 낡은 좌표를 누르던 문제 방지
        if (!n.refresh() || !n.isVisibleToUser) return false
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false

        val now = System.currentTimeMillis()
        val key = x.id + "|" + r.flattenToString()
        val log = clickLog.getOrPut(key) { ArrayList() }
        log.removeAll { now - it > 5000 }
        if (log.size >= 3) return false          // 눌러도 안 되는 대상은 잠시 포기
        val tries = log.size
        log.add(now)
        lastClick = now
        if (clickLog.size > 50) clickLog.entries.removeAll { e -> e.value.all { now - it > 5000 } }

        if (tries == 0) {
            // 자기 자신 또는 "버튼 크기"의 부모만 클릭 (광고 전체를 감싼 부모를 눌러 광고 페이지로 넘어가던 문제 방지)
            var p: AccessibilityNodeInfo? = n
            var i = 0
            while (p != null && i < 4) {
                if (p.isClickable && p.isEnabled && (i == 0 || smallParent(p, r, den))) {
                    if (p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                }
                p = p.parent
                i++
            }
        }
        // 접근성 클릭이 안 먹으면 실제 터치로
        tap(r)
        return true
    }

    private fun smallParent(p: AccessibilityNodeInfo, r: Rect, den: Float): Boolean {
        val pr = Rect(); p.getBoundsInScreen(pr)
        val lim = (120 * den).toInt()
        return pr.width() <= maxOf(lim, r.width() * 2) && pr.height() <= maxOf(lim, r.height() * 2)
    }

    private fun tap(r: Rect) {
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    // ---------- 진단: 현재 화면 구조를 클립보드로 ----------
    private fun dump() {
        val sb = StringBuilder()
        val dm = resources.displayMetrics
        sb.append("screen ${dm.widthPixels}x${dm.heightPixels} density ${dm.density} sdk ${Build.VERSION.SDK_INT}\n")
        sb.append("adWindow=$adWindow winPkg=$winPkg winClass=$winClass\n")
        try {
            for (w in windows) {
                sb.append("window type=${w.type} layer=${w.layer} focused=${w.isFocused} pkg=${w.root?.packageName}\n")
            }
        } catch (_: Exception) {}
        val root = pickRoot()
        if (root == null) {
            sb.append("(대상 창 없음: 광고 화면으로 이동하기 전에 실행됐을 수 있어요)\n")
        } else {
            var cnt = 0
            fun walk(n: AccessibilityNodeInfo?, depth: Int) {
                if (n == null || depth > 40 || cnt > 500) return
                cnt++
                val r = Rect(); n.getBoundsInScreen(r)
                sb.append("  ".repeat(depth))
                sb.append(n.className?.toString()?.substringAfterLast('.') ?: "?")
                n.viewIdResourceName?.let { sb.append(" id=").append(it.substringAfter('/')) }
                n.text?.let { sb.append(" t=\"").append(it.toString().take(30)).append('"') }
                n.contentDescription?.let { sb.append(" d=\"").append(it.toString().take(30)).append('"') }
                sb.append(" [${r.left},${r.top},${r.right},${r.bottom}]")
                if (n.isClickable) sb.append(" C")
                if (!n.isVisibleToUser) sb.append(" hidden")
                sb.append('\n')
                for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
            }
            walk(root, 0)
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("adskipper dump", sb.toString().take(30000)))
        Toast.makeText(this, "화면 구조를 복사했어요. 채팅에 붙여넣기 하세요", Toast.LENGTH_LONG).show()
    }
}
